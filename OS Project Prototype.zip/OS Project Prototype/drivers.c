#include <stdio.h>

void keyboard_driver() {
    printf("[DRIVER] Keyboard interrupt received.\n");
}

void disk_driver() {
    printf("[DRIVER] Disk read request handled.\n");
}

int main() {
    keyboard_driver();
    disk_driver();

    return 0;
}

