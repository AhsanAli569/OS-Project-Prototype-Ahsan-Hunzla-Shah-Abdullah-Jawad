#include <stdio.h>

int main() {
    int processes[] = {1, 2, 3};
    int burst[] = {5, 3, 7};
    int quantum = 2;

    printf("\n=== Round Robin Scheduling ===\n");

    int done = 0;
    while (!done) {
        done = 1;

        for (int i = 0; i < 3; i++) {
            if (burst[i] > 0) {
                int run = (burst[i] > quantum) ? quantum : burst[i];

                printf("Running Process %d for %d units\n", processes[i], run);
                burst[i] -= run;

                if (burst[i] > 0)
                    done = 0;
            }
        }
    }

    return 0;
}

