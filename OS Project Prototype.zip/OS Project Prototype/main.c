// =============================================================
// SHELL AND KERNEL INTERACTION MONITOR � COMPLETE PROTOTYPE
// =============================================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <semaphore.h>

// Global semaphore for synchronized logging
sem_t log_sem;

// Kernel simulator thread
void* kernel_simulator(void* arg) {
    char* syscall = (char*)arg;

    sem_wait(&log_sem);
    printf("\n[KERNEL] Received system call: %s\n", syscall);
    printf("[KERNEL] Processing...\n");
    sleep(1);
    printf("[KERNEL] Completed syscall: %s\n\n", syscall);
    sem_post(&log_sem);

    return NULL;
}

int main() {
    sem_init(&log_sem, 0, 1);

    char* syscalls[] = {
        "fork()", "read()", "write()", 
        "exec()", "wait()", "open()"
    };

    int count = sizeof(syscalls) / sizeof(syscalls[0]);

    printf("\n====== Shell and Kernel Interaction Monitor ======\n\n");

    for (int i = 0; i < count; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            printf("ERROR: Fork failed!\n");
            exit(1);
        }

        if (pid == 0) {
            printf("[SHELL] Requesting syscall: %s\n", syscalls[i]);

            pthread_t kernel_thread;
            pthread_create(&kernel_thread, NULL, kernel_simulator, syscalls[i]);
            pthread_join(kernel_thread, NULL);

            exit(0);
        } 
        else {
            wait(NULL);
        }
    }

    sem_destroy(&log_sem);
    return 0;
}

