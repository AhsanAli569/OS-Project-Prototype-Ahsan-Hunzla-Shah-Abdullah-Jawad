#include <stdio.h>

int memory[10] = {0};

void allocate(int pid) {
    for (int i = 0; i < 10; i++) {
        if (memory[i] == 0) {
            memory[i] = pid;
            printf("Allocated block %d to process %d\n", i, pid);
            return;
        }
    }
    printf("No free memory block!\n");
}

int main() {
    allocate(1);
    allocate(2);
    allocate(3);

    return 0;
}

