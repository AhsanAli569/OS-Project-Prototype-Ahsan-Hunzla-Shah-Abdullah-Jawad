#include <stdio.h>

int main() {
    int allocated[3] = {1, 2, 1};
    int max[3] = {3, 3, 3};
    int available = 2;

    printf("\n=== Deadlock Detection ===\n");

    for (int i = 0; i < 3; i++) {
        int need = max[i] - allocated[i];

        if (need <= available)
            printf("Process %d can finish (no deadlock).\n", i + 1);
        else
            printf("Process %d cannot finish ? Possible deadlock.\n", i + 1);
    }

    return 0;
}

